<!-- Bootstrap core JavaScript-->
<script src="assets/template/vendor/jquery/jquery.min.js"></script>
    <script src="assets/template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="assets/template/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="assets/template/js/sb-admin-2.min.js"></script>


    <script src="assets/DataTable/datatables.min.js"></script>
    <script> let table = new DataTable('#datatables'); </script>
PERBEDAAN Codingan DEPAN DENGAN CODINGAN SEPTYANNT :

tabel database : kalau di depan namanya peserta, kalau septyannt itu namanya pendaftaran